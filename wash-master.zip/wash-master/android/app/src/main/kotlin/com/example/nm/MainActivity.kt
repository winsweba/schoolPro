package com.example.nm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
